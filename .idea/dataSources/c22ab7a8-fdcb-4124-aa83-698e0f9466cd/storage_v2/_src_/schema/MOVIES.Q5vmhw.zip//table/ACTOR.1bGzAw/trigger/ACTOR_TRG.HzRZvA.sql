create trigger ACTOR_TRG
  before insert
  on ACTOR
  for each row
begin  
   if inserting then 
      if :NEW."ACTOR_ID" is null then 
         select ACTOR_SEQ.nextval into :NEW."ACTOR_ID" from dual; 
      end if; 
   end if; 
end;
/

